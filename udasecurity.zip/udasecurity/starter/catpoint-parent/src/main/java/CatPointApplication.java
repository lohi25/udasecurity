package com.udasecurity.catpoint.application;
// In CatPointApplication.java
import com.udasecurity.catpoint.securityservice.CatpointGui;
import com.udasecurity.catpoint.imageservice.FakeImageService;
import com.udasecurity.catpoint.imageservice.IImageService;
import com.udasecurity.catpoint.securityservice.SecurityService;
import com.udasecurity.catpoint.securityservice.InMemorySecurityRepository;
import javax.swing.SwingUtilities;

public class CatPointApplication {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {

            PretendDatabaseSecurityRepository securityRepository =
                    new PretendDatabaseSecurityRepository();

            IImageService imageService = new FakeImageService();

            SecurityService securityService =
                    new SecurityService(securityRepository, imageService);

            CatpointGui gui = new CatpointGui(securityService, imageService);
            gui.setVisible(true);
        });
    }
}
