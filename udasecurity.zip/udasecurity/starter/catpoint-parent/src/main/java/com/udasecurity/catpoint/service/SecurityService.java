package com.udasecuriy.catpoint.service;

import com.udasecurity.catpoint.data.AlarmStatus;
import com.udasecurity.catpoint.data.ArmingStatus;
import com.udasecurity.catpoint.data.Sensor;
import com.udasecurity.catpoint.image.ImageService;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;

public class SecurityService {

    private AlarmStatus alarmStatus = AlarmStatus.NO_ALARM;
    private ArmingStatus armingStatus = ArmingStatus.DISARMED;
    private final Set<Sensor> sensors = new HashSet<>();
    private final ImageService imageService;
    private boolean catDetected = false;

    public SecurityService(ImageService imageService) {
        this.imageService = imageService;
    }

    public void setArmingStatus(ArmingStatus status) {
        this.armingStatus = status;

        if (status == ArmingStatus.DISARMED) {
            setAlarmStatus(AlarmStatus.NO_ALARM);
            catDetected = false;
        } else {
            if (catDetected) {
                setAlarmStatus(AlarmStatus.ALARM);
            }
            // deactivate all sensors
            for (Sensor sensor : sensors) {
                sensor.setActive(false);
            }
        }
    }

    public void changeSensorActivationStatus(Sensor sensor, boolean active) {
        sensor.setActive(active);

        if (armingStatus == ArmingStatus.DISARMED) {
            return;
        }

        if (active) {
            if (alarmStatus == AlarmStatus.NO_ALARM) {
                setAlarmStatus(AlarmStatus.PENDING_ALARM);
            } else if (alarmStatus == AlarmStatus.PENDING_ALARM) {
                setAlarmStatus(AlarmStatus.ALARM);
            }
        } else {
            if (alarmStatus == AlarmStatus.PENDING_ALARM && allSensorsInactive()) {
                setAlarmStatus(AlarmStatus.NO_ALARM);
            }
        }
    }

    public void processImage(BufferedImage image) {
        catDetected = imageService.imageContainsCat(image, 50.0f);

        if (catDetected && armingStatus != ArmingStatus.DISARMED) {
            setAlarmStatus(AlarmStatus.ALARM);
        } else if (!catDetected && allSensorsInactive()) {
            setAlarmStatus(AlarmStatus.NO_ALARM);
        }
    }

    private boolean allSensorsInactive() {
        for (Sensor sensor : sensors) {
            if (sensor.getActive()) {
                return false;
            }
        }
        return true;
    }

    public void addSensor(Sensor sensor) {
        sensors.add(sensor);
    }

    public void removeSensor(Sensor sensor) {
        sensors.remove(sensor);
    }

    public AlarmStatus getAlarmStatus() {
        return alarmStatus;
    }

    private void setAlarmStatus(AlarmStatus status) {
        this.alarmStatus = status;
    }
}
