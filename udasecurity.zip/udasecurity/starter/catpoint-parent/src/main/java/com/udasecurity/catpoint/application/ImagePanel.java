package com.udasecurity.catpoint.application;

import com.udasecurity.catpoint.imageservice.IImageService;
import com.udasecurity.catpoint.securityservice.SecurityService;
import com.udasecurity.catpoint.securityservice.StyleService;
import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.awt.image.BufferedImage;

/**
 * Panel that displays the current camera feed and controls for image scanning.
 */
public class ImagePanel extends JPanel {

    private final SecurityService securityService;
    private final IImageService imageService;
    private final JLabel cameraLabel;
    private final JLabel cameraHeader;
    private BufferedImage currentImage;

    public ImagePanel(SecurityService securityService, IImageService imageService) {
        // Use MigLayout to organize the UI components
        super(new MigLayout());
        this.securityService = securityService;
        this.imageService = imageService;

        // 1. Setup the Header (Where it says "DANGER" or "READY")
        JLabel panelLabel = new JLabel("Camera Feed");
        panelLabel.setFont(StyleService.HEADING_FONT);
        add(panelLabel, "wrap");

        cameraHeader = new JLabel("READY");
        cameraHeader.setFont(StyleService.HEADING_FONT);
        add(cameraHeader, "wrap");

        // 2. Setup the Camera Image Display
        cameraLabel = new JLabel();
        cameraLabel.setHorizontalAlignment(JLabel.CENTER);
        // Set a preferred size so the UI doesn't jump around
        add(cameraLabel, "width 300:300:300, height 200:200:200, wrap");

        // 3. Create a panel to hold both buttons side-by-side
        JPanel buttonPanel = new JPanel(new MigLayout());

        JButton scanButton = new JButton("Scan Picture");
        scanButton.addActionListener(e -> {
            securityService.processImage(currentImage);
            // This updates the status based on your Awooga/Alarm logic
            cameraHeader.setText("SCAN COMPLETE");
        });

        // THIS IS THE BUTTON THE REVIEWER IS ASKING FOR
        JButton refreshButton = new JButton("Refresh Image");
        refreshButton.addActionListener(e -> {
            refreshImage();
        });

        buttonPanel.add(scanButton);
        buttonPanel.add(refreshButton);

        // Add the button group to the main panel
        add(buttonPanel, "wrap");

        // Load an initial image on startup
        refreshImage();
    }

    /**
     * Helper method to cycle through images in the resources folder.
     */
    private void refreshImage() {
        // Uses the alphabetical image cycle provided by the project
        currentImage = imageService.getAlphabeticalImage();
        cameraLabel.setIcon(new ImageIcon(currentImage));
        cameraHeader.setText("READY FOR SCAN");
    }
}