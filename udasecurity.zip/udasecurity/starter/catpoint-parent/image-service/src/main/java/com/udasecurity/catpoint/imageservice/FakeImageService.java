package com.udasecurity.catpoint.imageservice;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

/**
 * FakeImageService simulates a cat detection service.
 * SpotBugs-safe version: avoids catching broad Exception.
 */
public class FakeImageService implements IImageService {

    private boolean catToggle = false;

    @Override
    public BufferedImage scanImage() {
        catToggle = !catToggle;
        String imageName = catToggle ? "sample-cat.jpg" : "sample-not-cat.jpg";

        InputStream is = getClass().getClassLoader().getResourceAsStream(imageName);
        if (is == null) {
            throw new RuntimeException("Image not found: " + imageName);
        }

        try {
            return ImageIO.read(is);
        } catch (IOException e) {
            throw new RuntimeException("Unable to read image: " + imageName, e);
        }
    }

    @Override
    public boolean imageContainsCat(BufferedImage image, float confidenceThreshold) {
        Objects.requireNonNull(image, "image cannot be null");
        return catToggle;
    }
}
