package com.udasecurity.catpoint.imageservice;

import java.awt.image.BufferedImage;

public interface IImageService {
    BufferedImage scanImage();
    boolean imageContainsCat(BufferedImage image, float confidenceThreshold);
}