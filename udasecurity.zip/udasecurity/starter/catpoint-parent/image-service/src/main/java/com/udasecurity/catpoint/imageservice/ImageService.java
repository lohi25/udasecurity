package com.udasecurity.catpoint.securityservice.service;

import java.awt.image.BufferedImage;

public interface ImageService {

    BufferedImage scanImage();   // ✅ ADD THIS

    boolean imageContainsCat(BufferedImage image, float confidenceThreshold);
}
