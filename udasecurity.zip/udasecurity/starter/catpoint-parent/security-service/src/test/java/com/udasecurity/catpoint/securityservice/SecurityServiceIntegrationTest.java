package com.udasecurity.catpoint.securityservice;

import com.udasecurity.catpoint.imageservice.IImageService;
import com.udasecurity.catpoint.securityservice.data.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class SecurityServiceIntegrationTest {

    private SecurityService securityService;
    private SecurityRepository securityRepository;

    @Mock
    private IImageService imageService;

    @BeforeEach
    void init() {
        // Requirement: Use a FakeSecurityRepository instead of a Mock
        securityRepository = new FakeSecurityRepository();
        securityService = new SecurityService(securityRepository, imageService);
    }

    @Test
    void integration_changeSensorStatus_updatesRealRepository() {
        Sensor sensor = new Sensor(UUID.randomUUID().toString(), "Door", SensorType.DOOR, false);
        securityRepository.addSensor(sensor);
        securityRepository.setArmingStatus(ArmingStatus.ARMED_AWAY);

        // Act
        securityService.changeSensorActivationStatus(sensor, true);

        // Assert: Verify state in the real FakeRepository
        assertEquals(AlarmStatus.PENDING_ALARM, securityRepository.getAlarmStatus());
    }
}