package com.udasecurity.catpoint.securityservice.data;

public enum AlarmStatus {
    NO_ALARM, PENDING_ALARM, ALARM
}