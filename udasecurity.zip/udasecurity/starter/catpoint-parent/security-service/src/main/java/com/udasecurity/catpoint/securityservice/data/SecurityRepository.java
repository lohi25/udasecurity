package com.udasecurity.catpoint.securityservice.data;

import java.util.Set;

public interface SecurityRepository {
        void addSensor(Sensor sensor);
        void removeSensor(Sensor sensor); // The method currently causing the error
        void updateSensor(Sensor sensor);
        void setAlarmStatus(AlarmStatus alarmStatus);
        void setArmingStatus(ArmingStatus armingStatus);
        Set<Sensor> getSensors();
        AlarmStatus getAlarmStatus();
        ArmingStatus getArmingStatus();
}