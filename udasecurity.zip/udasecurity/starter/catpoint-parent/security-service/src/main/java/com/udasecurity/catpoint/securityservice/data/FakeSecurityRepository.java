package com.udasecurity.catpoint.securityservice.data;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Requirement: Create a FakeSecurityRepository class that works just like the
 * PretendDatabaseSecurityRepository class.
 *
 * SpotBugs fix:
 * - getSensors() now returns an unmodifiable copy of the internal set to prevent exposing internal representation.
 */
public class FakeSecurityRepository implements SecurityRepository {

    private final Set<Sensor> sensors = new HashSet<>();
    private AlarmStatus alarmStatus = AlarmStatus.NO_ALARM;
    private ArmingStatus armingStatus = ArmingStatus.DISARMED;

    @Override
    public void addSensor(Sensor sensor) {
        sensors.add(sensor);
    }

    @Override
    public void removeSensor(Sensor sensor) {
        sensors.remove(sensor);
    }

    @Override
    public void updateSensor(Sensor sensor) {
        // Remove old reference and add new reference to simulate update
        sensors.remove(sensor);
        sensors.add(sensor);
    }

    @Override
    public void setAlarmStatus(AlarmStatus alarmStatus) {
        this.alarmStatus = alarmStatus;
    }

    @Override
    public void setArmingStatus(ArmingStatus armingStatus) {
        this.armingStatus = armingStatus;
    }

    @Override
    public Set<Sensor> getSensors() {
        // Return a new unmodifiable copy to avoid exposing internal mutable set
        return Collections.unmodifiableSet(new HashSet<>(sensors));
    }

    @Override
    public AlarmStatus getAlarmStatus() {
        return alarmStatus;
    }

    @Override
    public ArmingStatus getArmingStatus() {
        return armingStatus;
    }
}
