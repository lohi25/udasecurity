package com.udasecurity.catpoint.securityservice.data;

public enum ArmingStatus {
    DISARMED, ARMED_HOME, ARMED_AWAY
}