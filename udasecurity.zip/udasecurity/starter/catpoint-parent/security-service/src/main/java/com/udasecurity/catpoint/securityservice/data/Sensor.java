package com.udasecurity.catpoint.securityservice.data;

import java.util.Objects;

/**
 * Sensor model representing a physical device in the security system.
 */
public class Sensor implements Comparable<Sensor> {

    private String name;
    private SensorType sensorType;
    private Boolean active;

    public Sensor(String name, String sensorId, SensorType sensorType, Boolean active) {
        this.name = name;
        this.sensorType = sensorType;
        this.active = active;
    }

    // This method allows the GUI to display the sensor type (DOOR, WINDOW, etc.)
    public SensorType getSensorType() {
        return sensorType;
    }

    public void setSensorType(SensorType sensorType) {
        this.sensorType = sensorType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    // Overriding compareTo, equals, and hashCode ensures the GUI list
    // and the Repository Set manage unique sensors correctly.
    @Override
    public int compareTo(Sensor o) {
        return Objects.compare(this.name, o.name, String::compareTo);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Sensor sensor = (Sensor) o;
        return Objects.equals(name, sensor.name) &&
                sensorType == sensor.sensorType &&
                Objects.equals(active, sensor.active);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, sensorType, active);
    }
}