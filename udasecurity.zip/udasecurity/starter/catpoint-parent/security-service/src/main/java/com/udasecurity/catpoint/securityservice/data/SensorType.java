package com.udasecurity.catpoint.securityservice.data;

public enum SensorType {
    DOOR, WINDOW, MOTION
}
