package com.udasecurity.catpoint.securityservice;

import com.udasecurity.catpoint.imageservice.IImageService;
import com.udasecurity.catpoint.imageservice.FakeImageService;
import com.udasecurity.catpoint.securityservice.data.*;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.Objects;

@SuppressFBWarnings("EI_EXPOSE_REP2")
public class CatpointGui extends JFrame {

    // Mark transient to fix SE_BAD_FIELD
    @SuppressFBWarnings("SE_BAD_FIELD")
    private transient final SecurityService securityService;

    @SuppressFBWarnings("SE_BAD_FIELD")
    private transient final IImageService imageService;

    private final JLabel statusLabel;
    private final JPanel sensorPanel;
    private final JLabel imageDisplay;
    private final JLabel scanStatusLabel;

    private final String[] imageFiles = {
            "sample-cat.jpg",
            "sample-not-cat.jpg",
            "sample-not-a-cat-fail.jpg"
    };
    private int currentImageIndex = 0;

    public CatpointGui(SecurityService securityService, IImageService imageService) {
        this.securityService = securityService;
        this.imageService = imageService;

        setTitle("Very Secure Home Security");
        setSize(900, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Top panel: system status
        JPanel headerPanel = new JPanel();
        statusLabel = new JLabel();
        statusLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerPanel.add(new JLabel("System Status: "));
        headerPanel.add(statusLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Left panel: Camera Feed & Scan
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(BorderFactory.createTitledBorder("Camera Feed"));

        scanStatusLabel = new JLabel("Camera Ready");
        scanStatusLabel.setFont(new Font("Arial", Font.ITALIC, 14));

        imageDisplay = new JLabel();
        imageDisplay.setPreferredSize(new Dimension(400, 300));
        imageDisplay.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        imageDisplay.setHorizontalAlignment(JLabel.CENTER);

        // Scan Button
        JButton scanButton = new JButton("Scan Picture");
        scanButton.addActionListener(e -> scanImage());

        // Next Image Button (to cycle images manually)
        JButton nextImageButton = new JButton("Next Image");
        nextImageButton.addActionListener(e -> {
            currentImageIndex = (currentImageIndex + 1) % imageFiles.length;
            String fileName = imageFiles[currentImageIndex];
            try {
                URL imageUrl = Objects.requireNonNull(getClass().getClassLoader().getResource(fileName),
                        "Image file not found: " + fileName);
                BufferedImage img = ImageIO.read(imageUrl);
                imageDisplay.setIcon(new ImageIcon(img.getScaledInstance(400, 300, Image.SCALE_SMOOTH)));
                scanStatusLabel.setText("Ready to Scan: " + fileName);
            } catch (IOException ex) {
                ex.printStackTrace();
                scanStatusLabel.setText("Error loading image: " + fileName);
            }
        });

        leftPanel.add(scanStatusLabel);
        leftPanel.add(imageDisplay);
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(scanButton);
        leftPanel.add(Box.createVerticalStrut(5));
        leftPanel.add(nextImageButton);
        add(leftPanel, BorderLayout.WEST);

        // Center panel: Sensor Management
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(BorderFactory.createTitledBorder("Sensor Management"));

        JPanel addSensorPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField nameField = new JTextField(10);
        JComboBox<SensorType> typeBox = new JComboBox<>(SensorType.values());
        JButton addButton = new JButton("Add New Sensor");

        addButton.addActionListener(e -> {
            if (!nameField.getText().isBlank()) {
                securityService.addSensor(new Sensor(nameField.getText(), "",
                        Objects.requireNonNull((SensorType) typeBox.getSelectedItem()), false));
                updateUIComponents();
            }
        });

        addSensorPanel.add(new JLabel("Name:"));
        addSensorPanel.add(nameField);
        addSensorPanel.add(typeBox);
        addSensorPanel.add(addButton);

        sensorPanel = new JPanel();
        sensorPanel.setLayout(new BoxLayout(sensorPanel, BoxLayout.Y_AXIS));

        centerPanel.add(addSensorPanel, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(sensorPanel), BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);

        // Bottom panel: Arming Status Controls
        JPanel controlPanel = new JPanel();
        for (ArmingStatus status : ArmingStatus.values()) {
            JButton btn = new JButton(status.toString());
            btn.addActionListener(e -> {
                securityService.setArmingStatus(status);
                updateUIComponents();
            });
            controlPanel.add(btn);
        }
        add(controlPanel, BorderLayout.SOUTH);

        updateUIComponents();
    }

    private void scanImage() {
        String fileName = imageFiles[currentImageIndex];
        try {
            URL imageUrl = Objects.requireNonNull(getClass().getClassLoader().getResource(fileName),
                    "Image file not found: " + fileName);
            BufferedImage img = ImageIO.read(imageUrl);
            imageDisplay.setIcon(new ImageIcon(img.getScaledInstance(400, 300, Image.SCALE_SMOOTH)));

            securityService.processImage(img);

            if (fileName.contains("cat") && !fileName.contains("not")) {
                scanStatusLabel.setText("DANGER - CAT DETECTED");
            } else {
                scanStatusLabel.setText("No Cats Detected");
            }

            updateUIComponents();

        } catch (IOException e) {
            e.printStackTrace();
            scanStatusLabel.setText("Error loading image: " + fileName);
        }
    }

    private void updateUIComponents() {
        updateStatusDisplay();
        updateSensorDisplay();
    }

    private void updateStatusDisplay() {
        AlarmStatus alarm = securityService.getAlarmStatus();
        ArmingStatus arming = securityService.getArmingStatus();

        if (alarm == AlarmStatus.ALARM) {
            statusLabel.setText("Awooga!");
            statusLabel.setBackground(Color.RED);
            statusLabel.setOpaque(true);
            statusLabel.setForeground(Color.WHITE);
        } else if (alarm == AlarmStatus.NO_ALARM) {
            statusLabel.setText("Cool and Good");
            statusLabel.setBackground(Color.GREEN);
            statusLabel.setOpaque(true);
            statusLabel.setForeground(Color.BLACK);
        } else {
            statusLabel.setText(arming.toString());
            statusLabel.setBackground(null);
            statusLabel.setOpaque(false);
            statusLabel.setForeground(Color.BLACK);
        }
    }

    private void updateSensorDisplay() {
        sensorPanel.removeAll();
        for (Sensor s : securityService.getSensors()) {
            JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JLabel info = new JLabel(String.format("%s (%s): %s",
                    s.getName(), s.getSensorType(), s.getActive() ? "Active" : "Inactive"));

            JButton toggle = new JButton(s.getActive() ? "Deactivate" : "Activate");
            toggle.addActionListener(e -> {
                securityService.changeSensorActivationStatus(s, !s.getActive());
                updateUIComponents();
            });

            JButton remove = new JButton("Remove Sensor");
            remove.addActionListener(e -> {
                securityService.removeSensor(s);
                updateUIComponents();
            });

            row.add(info);
            row.add(toggle);
            row.add(remove);
            sensorPanel.add(row);
        }
        sensorPanel.revalidate();
        sensorPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SecurityRepository repo = new FakeSecurityRepository();
            IImageService imgService = new FakeImageService();
            SecurityService ss = new SecurityService(repo, imgService);
            new CatpointGui(ss, imgService).setVisible(true);
        });
    }
}
