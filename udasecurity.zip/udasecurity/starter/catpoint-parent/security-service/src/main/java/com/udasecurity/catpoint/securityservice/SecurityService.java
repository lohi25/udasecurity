package com.udasecurity.catpoint.securityservice;

import com.udasecurity.catpoint.imageservice.IImageService;
import com.udasecurity.catpoint.securityservice.data.*;

import java.awt.image.BufferedImage;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


public class SecurityService {

    private final SecurityRepository securityRepository;
    private final IImageService imageService;
    private boolean catDetected = false;

    public SecurityService(SecurityRepository securityRepository, IImageService imageService) {
        this.securityRepository = Objects.requireNonNull(securityRepository, "securityRepository cannot be null");
        this.imageService = Objects.requireNonNull(imageService, "imageService cannot be null");
    }

    public void changeSensorActivationStatus(Sensor sensor, boolean active) {
        Objects.requireNonNull(sensor, "sensor cannot be null");

        sensor.setActive(active);
        securityRepository.updateSensor(sensor);

        if (securityRepository.getArmingStatus() == ArmingStatus.DISARMED) {
            return;
        }

        if (active) {
            if (securityRepository.getAlarmStatus() == AlarmStatus.NO_ALARM) {
                securityRepository.setAlarmStatus(AlarmStatus.PENDING_ALARM);
            } else if (securityRepository.getAlarmStatus() == AlarmStatus.PENDING_ALARM) {
                securityRepository.setAlarmStatus(AlarmStatus.ALARM);
            }
        } else {
            if (securityRepository.getAlarmStatus() == AlarmStatus.PENDING_ALARM && allSensorsInactive()) {
                securityRepository.setAlarmStatus(AlarmStatus.NO_ALARM);
            }
        }
    }

    public void processImage(BufferedImage currentImage) {
        Objects.requireNonNull(currentImage, "currentImage cannot be null");

        try {
            catDetected = imageService.imageContainsCat(currentImage, 50.0f);
        } catch (RuntimeException e) {
            // Catch only runtime exceptions from imageService
            throw new RuntimeException("Failed to process image for cat detection", e);
        }

        if (catDetected && securityRepository.getArmingStatus() != ArmingStatus.DISARMED) {
            securityRepository.setAlarmStatus(AlarmStatus.ALARM);
            return;
        }

        if (!catDetected && allSensorsInactive()) {
            securityRepository.setAlarmStatus(AlarmStatus.NO_ALARM);
        }
    }

    public void setArmingStatus(ArmingStatus armingStatus) {
        Objects.requireNonNull(armingStatus, "armingStatus cannot be null");

        securityRepository.setArmingStatus(armingStatus);

        if (armingStatus == ArmingStatus.DISARMED) {
            securityRepository.setAlarmStatus(AlarmStatus.NO_ALARM);
            catDetected = false;
            return;
        }

        for (Sensor sensor : securityRepository.getSensors()) {
            sensor.setActive(false);
            securityRepository.updateSensor(sensor);
        }

        if (catDetected) {
            securityRepository.setAlarmStatus(AlarmStatus.ALARM);
        }
    }

    private boolean allSensorsInactive() {
        return securityRepository.getSensors().stream().noneMatch(Sensor::getActive);
    }

    // ----- Getters for testing -----
    public AlarmStatus getAlarmStatus() {
        return securityRepository.getAlarmStatus();
    }

    public ArmingStatus getArmingStatus() {
        return securityRepository.getArmingStatus();
    }

    public Set<Sensor> getSensors() {
        return Collections.unmodifiableSet(new HashSet<>(securityRepository.getSensors()));
    }

    public void addSensor(Sensor sensor) {
        Objects.requireNonNull(sensor, "sensor cannot be null");
        securityRepository.addSensor(sensor);
    }

    public void removeSensor(Sensor sensor) {
        Objects.requireNonNull(sensor, "sensor cannot be null");
        securityRepository.removeSensor(sensor);
    }
}
