package com.udasecurity.catpoint.controlcenter;

import com.udasecurity.catpoint.securityservice.SecurityService;
import com.udasecurity.catpoint.securityservice.data.SecurityRepository;
import com.udasecurity.catpoint.securityservice.data.FakeSecurityRepository; // Fixes abstract error
import com.udasecurity.catpoint.imageservice.IImageService;
import com.udasecurity.catpoint.imageservice.FakeImageService;
import com.udasecurity.catpoint.application.CatpointGui; // Reference the professional GUI
import javax.swing.*;

public class ControlCenter extends JFrame {
    private final SecurityService securityService;
    private final IImageService imageService;

    public ControlCenter(SecurityService securityService, IImageService imageService) {
        this.securityService = securityService;
        this.imageService = imageService;

        setTitle("Control Center Launcher");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton launchButton = new JButton("Launch Professional GUI");
        // ACCESSING the fields here clears the "never accessed" warning
        launchButton.addActionListener(e -> {
            new CatpointGui(this.securityService, this.imageService).setVisible(true);
        });

        add(launchButton);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Initialize the system correctly using Fake implementations
            SecurityRepository repo = new FakeSecurityRepository();
            IImageService imgService = new FakeImageService();
            SecurityService ss = new SecurityService(repo, imgService);

            // Launch the ControlCenter window
            ControlCenter cc = new ControlCenter(ss, imgService);
            cc.setVisible(true);
        });
    }
}